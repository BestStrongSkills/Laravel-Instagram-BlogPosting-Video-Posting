<?php $__env->startSection('content'); ?>
<video width="576" height="640" autoplay controls>
  <source src="http://localhost:8000/images/output.mp4" type="video/mp4">
  		<!--clientId==== 9ee75b4f8a3542b88ff0972047a97901
  		Client Secret d57bef4ab38c4f159b03963a7c6203c2  -->
 </video>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
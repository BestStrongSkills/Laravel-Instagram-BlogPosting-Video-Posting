<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(Route('view',$token)); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<div class="form-group">
		<div class="row">
			<select name="image[]" multiple="multiple" class="form-control image-picker">
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instagram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option data-img-src='<?php echo e($instagram->images->thumbnail->url); ?>' value="<?php echo e($instagram->id); ?>">1</option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<div class="row">
			<label for="music" class="col-md-2" style="background-color:blue;border-radius:4px;">MusicSecetion:</label>
			<input type="file" class="col-md-6" name="mp3file" accept=".mp3">
			<button type="submit" class="col-md-3 btn btn-primary">VideoPlay</button>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_script'); ?>
<script type="text/javascript">
	(function(){
		$('select').imagepicker();
	})();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
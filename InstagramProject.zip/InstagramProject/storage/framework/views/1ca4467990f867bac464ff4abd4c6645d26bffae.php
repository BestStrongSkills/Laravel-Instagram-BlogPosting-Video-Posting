<?php $__env->startSection('content'); ?>
<form action="<?php echo e(Route('showGallery')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <div class="row">
            <label class="col-md-4">Account token</label>
            <input type="text" name="token_value" class="form-control col-md-8">
        </div>
    </div>
    <div class="form-group">
        <div class="row">
            <label class="col-md-4"></label>
            <button type="submit" class="btn btn-primary col-md-8">Show Instagram Media Gallery</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
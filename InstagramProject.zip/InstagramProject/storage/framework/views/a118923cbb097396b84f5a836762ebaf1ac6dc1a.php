<?php $__env->startSection('content'); ?>
<video width="600" height="480" autoplay controls>
  <source src="http://localhost:8000/images/output.mp4" type="video/mp4">
 </video>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
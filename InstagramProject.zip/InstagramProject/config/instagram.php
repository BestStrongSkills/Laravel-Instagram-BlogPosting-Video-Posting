<?php
return [
    // 'client_id' => env('INSTAGRAM_KEY'),
    // 'client_secret' => env('INSTAGRAM_SECRET'),
    // 'callback_url' => env('INSTAGRAM_REDIRECT_URI'),

    'client_id' => '34b69971717940e99eaee4e9354b74aa',
    'client_secret' => 'fff3393957c4428b843560e8e00d79f5',
    'callback_url' => 'http://127.0.0.1:8000/login/instagram/callback',
 //    INSTAGRAM_KEY= 9501f0c92af74a0cab4cb5e99d4cb547
	// INSTAGRAM_SECRET=6f84ed77a66d427fb5614c3a40a3b046   
	// INSTAGRAM_REDIRECT_URI=http://localhost/instagram/callback/
];
// 6766259795.1677ed0.c04f84bbf9144955a55f1504e04bf421
@extends('layouts.app')

@section('content')
<a href="{{url('/login/instagram/')}}">
    InstagramLogin
</a>
@endsection